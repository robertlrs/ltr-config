#!/bin/bash

cp -r src/main/java/* ~/workspace/open_source/elasticsearch-ltr/plugins/ltr/src/main/java/

gradle clean build -x test


rm ./tmp/*.zip
cp /Users/luorenshu/workspace/open_source/learning-to-rank/build/distributions/*.zip ./tmp/

cd tmp 
rm -rf elasticsearch
unzip *.zip

rm /Users/luorenshu/workspace/open_source/elasticsearch-ltr/distribution/src/main/resources/plugins/ltr/*
cp elasticsearch/* /Users/luorenshu/workspace/open_source/elasticsearch-ltr/distribution/src/main/resources/plugins/ltr/

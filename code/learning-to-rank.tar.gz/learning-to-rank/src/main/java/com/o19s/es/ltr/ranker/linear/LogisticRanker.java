package com.o19s.es.ltr.ranker.linear;

import com.o19s.es.ltr.feature.CrossFeature;
import com.o19s.es.ltr.feature.store.StoredFeature;
import com.o19s.es.ltr.ranker.DenseFeatureVector;
import com.o19s.es.ltr.ranker.DenseLtrRanker;
import org.apache.lucene.util.Accountable;
import org.apache.lucene.util.RamUsageEstimator;

import java.util.*;

import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_ARRAY_HEADER;
import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_OBJECT_HEADER;
import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_OBJECT_REF;

/**
 * @author: zhou yafeng
 * @create: 2018/06/27
 */
public class LogisticRanker extends DenseLtrRanker implements Accountable {
    private final float[] weights;
    private final Map<String, Float> cross_weights;
    private final List<CrossFeature> cross_fields;

    public LogisticRanker(float[] weights, Map<String, Float> cross_weights, List<CrossFeature> cross_fields) {
        this.weights = Objects.requireNonNull(weights);
        this.cross_weights = cross_weights;
        this.cross_fields = cross_fields;
    }

    @Override
    public String name() {
        return "logistic";
    }

    @Override
    public List<CrossFeature> getCrossFeatures() {
        return cross_fields;
    }
    @Override
    protected float score(DenseFeatureVector point, List<String> cross_features) {
        float[] scores = point.scores;
        float score = 0;
        for (int i = 0; i < weights.length; i++) {
            if (scores[i] > 0) {
                score += weights[i]*scores[i];
            }
        }

        if (cross_features != null) {
            Set<String> features = cross_weights.keySet();
            for (String feature : cross_features) {
                if (features.contains(feature)) {
                    score += cross_weights.get(feature);
                }
            }
        }
        return score;
    }

    @Override
    protected int size() {
        return weights.length;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LogisticRanker ranker = (LogisticRanker) o;

        return Arrays.equals(weights, ranker.weights);
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(weights);
    }

    /**
     * Return the memory usage of this object in bytes. Negative values are illegal.
     */
    @Override
    public long ramBytesUsed() {
        return RamUsageEstimator.NUM_BYTES_OBJECT_HEADER + RamUsageEstimator.sizeOf(weights) +
            NUM_BYTES_ARRAY_HEADER +
            NUM_BYTES_ARRAY_HEADER +
            cross_fields.stream().mapToLong(CrossFeature::ramBytesUsed).sum() +
            cross_weights.size() * NUM_BYTES_OBJECT_REF + NUM_BYTES_OBJECT_HEADER;
    }
}

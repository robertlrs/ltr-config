package com.o19s.es.ltr.feature.store.script;

import org.elasticsearch.common.ParseField;
import org.elasticsearch.common.xcontent.ObjectParser;
import org.elasticsearch.common.xcontent.XContentParser;

public class ScriptScore {

    public static final String TYPE = "script_score";

    static final ParseField SCRIPT = new ParseField("script");

    private static final ObjectParser<ParsingState, Void> PARSER;

    private ScriptFunction scriptFunction;

    static {
        PARSER = new ObjectParser<>(TYPE, ParsingState::new);
        PARSER.declareObject(ParsingState::setScript,
            (parser, ctx) -> ScriptFunction.parse(parser),
            SCRIPT);
    }

    public static ScriptScore parse(XContentParser parser) {
        ParsingState state = PARSER.apply(parser, null);

        ScriptScore scriptScore = new ScriptScore();
        scriptScore.setScriptFunction(state.scriptFunction);

        return scriptScore;
    }

    public ScriptFunction getScriptFunction() {
        return scriptFunction;
    }

    public void setScriptFunction(ScriptFunction scriptFunction) {
        this.scriptFunction = scriptFunction;
    }

    private static class ParsingState {
        ScriptFunction scriptFunction;

        void setScript(ScriptFunction scriptFunction) {
            this.scriptFunction = scriptFunction;
        }
    }
}

package com.o19s.es.ltr.feature.store.script;

import org.elasticsearch.common.ParseField;
import org.elasticsearch.common.xcontent.ObjectParser;
import org.elasticsearch.common.xcontent.XContentParser;

public class TemplateContent {
    public static final String TYPE = "template";


    private static final ObjectParser<ParsingState, Void> PARSER;

    static final ParseField FUNCTION_SCORE = new ParseField("function_score");

    static {
        PARSER = new ObjectParser<>(TYPE, ParsingState::new);
        PARSER.declareObject(ParsingState::setFunctionScore,
            (parser, ctx) -> FunctionScore.parse(parser),
            FUNCTION_SCORE);
    }

    public static FunctionScore parse(XContentParser parser) {
        ParsingState state = PARSER.apply(parser, null);

        return state.functionScore;
    }


    private static class ParsingState {
        FunctionScore functionScore;

        void setFunctionScore(FunctionScore functionScore) {
            this.functionScore = functionScore;
        }

    }
}

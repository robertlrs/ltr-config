package com.o19s.es.ltr.feature;

import com.o19s.es.ltr.feature.store.StoredFeature;
import org.apache.lucene.util.RamUsageEstimator;

import java.util.List;

import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_ARRAY_HEADER;
import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_OBJECT_HEADER;
import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_OBJECT_REF;

/**
 * @author: zhou yafeng
 * @create: 2018/07/06
 */
public class CrossFeature {
    private static final long BASE_RAM_USED = RamUsageEstimator.shallowSizeOfInstance(CrossFeature.class);
    private final List<String> fields;

    public CrossFeature(List<String> fields) {
        this.fields = fields;
    }

    public List<String> fields() {
        return fields;
    }

    public long ramBytesUsed() {
        // rough estimation...
        return BASE_RAM_USED +
            NUM_BYTES_ARRAY_HEADER +
            fields.stream().mapToLong(x -> (Character.BYTES * x.length()) +
                NUM_BYTES_OBJECT_REF + NUM_BYTES_OBJECT_HEADER + NUM_BYTES_ARRAY_HEADER).sum();
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof CrossFeature)) {
            return false;
        }

        CrossFeature that = (CrossFeature) o;
        return fields.equals(that.fields);
    }

    public int hashCode() {
        int result = fields.hashCode();
        return result;
    }
}

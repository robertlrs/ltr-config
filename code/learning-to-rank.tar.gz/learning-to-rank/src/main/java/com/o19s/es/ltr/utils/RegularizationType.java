package com.o19s.es.ltr.utils;

/**
 * @author: zhou yafeng
 * @create: 2018/06/27
 */
public class RegularizationType {
    public static final String NONE = "NONE";

    public static final String L1 = "L1";

    public static final String L2 = "L2";

}

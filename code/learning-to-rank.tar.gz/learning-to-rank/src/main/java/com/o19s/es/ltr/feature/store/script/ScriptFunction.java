package com.o19s.es.ltr.feature.store.script;

import org.elasticsearch.common.ParseField;
import org.elasticsearch.common.xcontent.ObjectParser;
import org.elasticsearch.common.xcontent.XContentParser;

public class ScriptFunction {

    public static final String TYPE = "script";

    private static final ParseField SOURCE = new ParseField("source");

    private static final ObjectParser<ParsingState, Void> PARSER;

    static {
        PARSER = new ObjectParser<>(TYPE, ParsingState::new);
        PARSER.declareString(ParsingState::setSource, SOURCE);
    }

    private String source;


    public static ScriptFunction parse(XContentParser parser) {
        ParsingState state = PARSER.apply(parser, null);

        ScriptFunction script = new ScriptFunction(state.source);

        return script;
    }

    public ScriptFunction(String source) {
        this.source = source;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    private static class ParsingState {
        String source;

        void setSource(String source) {
            this.source = source;
        }
    }
}

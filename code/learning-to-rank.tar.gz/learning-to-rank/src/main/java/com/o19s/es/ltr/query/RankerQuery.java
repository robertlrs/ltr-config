/*
 * Copyright [2017] Doug Turnbull, Wikimedia Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.o19s.es.ltr.query;

import com.o19s.es.ltr.LtrQueryContext;
import com.o19s.es.ltr.feature.*;
import com.o19s.es.ltr.ranker.LogLtrRanker;
import com.o19s.es.ltr.ranker.LtrRanker;
import com.o19s.es.ltr.ranker.NullRanker;
import com.o19s.es.ltr.utils.Suppliers.MutableSupplier;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.lucene.index.*;
import org.apache.lucene.search.ConstantScoreScorer;
import org.apache.lucene.search.ConstantScoreWeight;
import org.apache.lucene.search.DocIdSetIterator;
import org.apache.lucene.search.Explanation;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Scorer;
import org.apache.lucene.search.Weight;
import org.apache.lucene.util.BytesRef;


import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Lucene query designed to apply a ranking model provided by {@link LtrRanker}
 * This query is not designed for retrieval, in other words it will score
 * all the docs in the index and thus must be used either in a rescore phase
 * or within a BooleanQuery and an appropriate filter clause.
 */
public class RankerQuery extends Query {
    //private static final Logger logger = LogManager.getLogger(RankerQuery.class);
    private static String DELIMITER = "=";
    private final List<Query> queries;
    private final FeatureSet features;
    private final LtrRanker ranker;
    private final Map<String, Object> params;

    private RankerQuery(List<Query> queries, FeatureSet features, LtrRanker ranker, Map<String, Object> params) {
        this.queries = Objects.requireNonNull(queries);
        this.features = Objects.requireNonNull(features);
        this.ranker = Objects.requireNonNull(ranker);
        this.params = params;
    }

    /**
     * Build a RankerQuery based on a prebuilt model.
     * Prebuilt models are not parametrized as they contain only {@link com.o19s.es.ltr.feature.PrebuiltFeature}
     *
     * @param model a prebuilt model
     * @return the lucene query
     */
    public static RankerQuery build(PrebuiltLtrModel model) {
        return build(model.ranker(), model.featureSet(), new LtrQueryContext(null, Collections.emptySet()), Collections.emptyMap());
    }

    /**
     * Build a RankerQuery.
     *
     * @param model   The model
     * @param context the context used to parse features into lucene queries
     * @param params  the query params
     * @return the lucene query
     */
    public static RankerQuery build(LtrModel model, LtrQueryContext context, Map<String, Object> params) {
        return build(model.ranker(), model.featureSet(), context, params);
    }

    private static RankerQuery build(LtrRanker ranker, FeatureSet features, LtrQueryContext context, Map<String, Object> params) {
        List<Query> queries = features.toQueries(context, params);
        return new RankerQuery(queries, features, ranker, params);
    }

    public static RankerQuery buildLogQuery(LogLtrRanker.LogConsumer consumer, FeatureSet features,
                                            LtrQueryContext context, Map<String, Object> params) {
        List<Query> queries = features.toQueries(context, params);
        return new RankerQuery(queries, features, new LogLtrRanker(consumer, features.size()), null);
    }

    public RankerQuery toLoggerQuery(LogLtrRanker.LogConsumer consumer, boolean replaceWithNullRanker) {
        LtrRanker newRanker = ranker;
        if (replaceWithNullRanker && !(ranker instanceof NullRanker)) {
            newRanker = new NullRanker(features.size());
        }
        return new RankerQuery(queries, features, new LogLtrRanker(newRanker, consumer), null);
    }

    @Override
    public Query rewrite(IndexReader reader) throws IOException {
        List<Query> rewrittenQueries = new ArrayList<>(queries.size());
        boolean rewritten = false;
        for (Query query : queries) {
            Query rewrittenQuery = query.rewrite(reader);
            rewritten |= rewrittenQuery != query;
            rewrittenQueries.add(rewrittenQuery);
        }
        return rewritten ? new RankerQuery(rewrittenQueries, features, ranker, null) : this;
    }

    @Override
    public boolean equals(Object obj) {
        // This query should never be cached
        if (this == obj) {
            return true;
        }
        if (!sameClassAs(obj)) {
            return false;
        }
        RankerQuery that = (RankerQuery) obj;
        return Objects.deepEquals(queries, that.queries) &&
                Objects.deepEquals(features, that.features) &&
                Objects.equals(ranker, that.ranker);
    }

    Stream<Query> stream() {
        return queries.stream();
    }

    @Override
    public int hashCode() {
        return 31 * classHash() + Objects.hash(features, queries, ranker);
    }

    @Override
    public String toString(String field) {
        return "rankerquery:" + field;
    }

    /**
     * Return feature at ordinal
     */
    Feature getFeature(int ordinal) {
        return features.feature(ordinal);
    }

    /**
     * @Description: find the original feature id via the queryid
     * @param:
     * @return:
     * @Author: zhou yafeng
     * @Date: 2018/7/4
    */

    int getOriginalID(int ordinal) {
        return features.featureOrdinal(ordinal);
    }
    /**
     * @Description:
     * @param:
     * @return:
     * @Author: zhou yafeng
     * @Date: 2018/7/2
    */
    int featureOrdinal(String feature){
        return features.featureOrdinal(feature);
    }

    /**
     * The ranker used by this query
     */
    LtrRanker ranker() {
        return ranker;
    }

    public FeatureSet featureSet() {
        return features;
    }

    @Override
    public Weight createWeight(IndexSearcher searcher, boolean needsScores, float boost) throws IOException {
        if (!needsScores) {
            // If scores are not needed simply return a constant score on all docs
            return new ConstantScoreWeight(this, boost) {
                @Override
                public Scorer scorer(LeafReaderContext context) throws IOException {
                    return new ConstantScoreScorer(this, score(), DocIdSetIterator.all(context.reader().maxDoc()));
                }

                @Override
                public boolean isCacheable(LeafReaderContext ctx) {
                    return true;
                }
            };
        }
        List<Weight> weights = new ArrayList<>(queries.size());
        for (Query q : queries) {
            weights.add(searcher.createWeight(q, needsScores, boost));
        }
        return new RankerWeight(weights);
    }

    public class RankerWeight extends Weight {
        private final List<Weight> weights;

        @Override
        public boolean isCacheable(LeafReaderContext ctx) {
            for (Weight w : weights) {
                if (w.isCacheable(ctx) == false) {
                    return false;
                }
            }
            return true;
        }

        RankerWeight(List<Weight> weights) {
            super(RankerQuery.this);
            assert weights instanceof RandomAccess;
            this.weights = weights;
        }

        @Override
        public void extractTerms(Set<Term> terms) {
            for (Weight w : weights) {
                w.extractTerms(terms);
            }
        }

        @Override
        public Explanation explain(LeafReaderContext context, int doc) throws IOException {
            List<Explanation> subs = new ArrayList<>(weights.size());

            LtrRanker.FeatureVector d = ranker.newFeatureVector(null);
            int ordinal = -1;
            int realordinal = -1;

            //保存discrete属性的字段对应的值, 其中range类型属性的key为字段值，value为字段值对应的区间编号
            Map<String, String> fieldMap = new HashMap<>();

            for (Weight weight : weights) {
                ordinal++;
                realordinal = getOriginalID(ordinal);
                final Explanation explain;
                if (weight instanceof FeatureVectorWeight) {
                    explain = ((FeatureVectorWeight) weight).explain(context, d, doc);
                } else {
                    explain = weight.explain(context, doc);
                }

                float score = explain.getValue();
                Feature feature = features.feature(realordinal);

                String featureString = "Feature ";
                String channel = feature.channel();
                boolean find = true;
                //获取特征用到的输入参数的字段名，目前只考虑一个输入参数的情况
                List<String> queryParams = (List<String>) feature.queryParams();
                String attrType = feature.attrType();
                switch (attrType) {
                    case "categorical": {
                        //字段值，input型：传入参数获取， hybrid，query：从查询中获取
                        String fieldValue;
                        String featureName;
                        //是否找到了onehot的那位，因为hybrid型需要再匹配一次(不一定每个样本都有onehot bit），input和query类型一定有onehot bit

                        switch (channel) {
                            case "input": {
                                String key = queryParams.get(0);
                                //根据字段名，从sltr查询的输入params获取value
                                Object value = params.get(key);
                                fieldValue = value.toString();
                                if (value instanceof Integer) {
                                    Integer tempValue = (Integer)value;
                                    if (tempValue > feature.max()) {
                                        fieldValue = Integer.toString(0);
                                    }
                                }
                                //先获取完整的特征变量名
                                featureName = feature.field() + DELIMITER + fieldValue;
                                //根据变量名获取实际的index
                                realordinal = featureOrdinal(featureName);
                                break;
                            }
                            //既查询又匹配型特征
                            case "hybrid":
                            case "query":
                            case "binary": {
                                //之前版本discrete 属性的值得从0开始（不支持string类型,float类型）
                                //属性增加field字段，discrete属性命名：field名=field值，都必须是string类型
                                switch (feature.fieldType()) {
                                    case "int": {
                                        if ((int) score > feature.max()) {
                                            score = 0f;
                                        }
                                        fieldValue = Integer.toString((int) score);
                                        break;
                                    }
                                    default:
                                        throw new IllegalArgumentException("Wrong field_type: [" + feature.fieldType() + "]");
                                }

                                //混合型还需要匹配params step 1: 解析传入的参数，这里是个list integer
                                if (channel.equals("hybrid") || channel.equals("binary")) {
                                    String key = queryParams.get(0);
                                    Object values = params.get(key);
                                    //加上抑制处理，否则在编译时报错
                                    @SuppressWarnings("unchecked")
                                    List<Object> a = (ArrayList<Object>) values;
                                    List<Integer> objects = a.stream().map(x -> {
                                        if (x instanceof Integer) {
                                            return (Integer) x;
                                        } else {
                                            throw new IllegalArgumentException("Wrong input params: [" + x + "]");
                                        }
                                    }).collect(Collectors.toList());

                                    //step 2: 根据查询的值来匹配传入的参数
                                    if (objects.contains((int) score)) {
                                        find = true;
                                        //字段值为1
                                        if (channel.equals("binary")){
                                            fieldValue = Integer.toString(1);
                                        }
                                    } else {
                                        find = false;
                                        //字段值为0
                                        if (channel.equals("binary")){
                                            fieldValue = Integer.toString(0);
                                        }
                                    }
                                }

                                //先获取完整的特征变量名
                                featureName = feature.field() + DELIMITER + fieldValue;
                                //根据变量名获取实际的index
                                realordinal = featureOrdinal(featureName);

                                break;
                            }
                            default:
                                throw new IllegalArgumentException("Wrong channel type: [" + channel + "]");
                        }

                        //保存离散型特征的具体字段值，用于交叉特征时找到具体的维度
                        fieldMap.put(feature.field(), fieldValue);
                        break;
                    }
                    case "range": {
                        //对应的区间需要添加到fieldMap以便用于交叉特征
                        if ((int)score == 1) {
                            find = true;
                            fieldMap.put(feature.field(), Integer.toString(feature.index()));
                        } //非区间的属性不需要设置特征向量
                        else{
                            find = false;
                        }
                        break;
                    }
                    case "embedding":
                    case "non-discrete" : {
                        break;
                    }
                    default:
                        throw new IllegalArgumentException("Wrong attr_type: [" + feature.attrType() + "]");

                }
                featureString += Integer.toString(realordinal);
                if (features.feature(realordinal).name() != null) {
                    featureString += "(" + features.feature(realordinal).name() + ")";
                }

                featureString += ":";
                if (!explain.isMatch()) {
                    subs.add(Explanation.noMatch(featureString + " [no match, default value 0.0 used]"));
                } else {
                    switch (attrType) {
                        case "categorical":
                        case "range": {
                            if (find) {
                                //对于hybrid型，没有onehot bit时不需要做处理
                                subs.add(Explanation.match(explain.getValue(), featureString, explain));
                                d.setFeatureScore(realordinal, 1);
                            }
                            break;
                        }
                        case "embedding": {
                            String key = queryParams.get(0);
                            Object objects = params.get(key);
                            @SuppressWarnings("unchecked")
                            List<Object> a = (ArrayList<Object>) objects;
                            List<Double> srcVector = a.stream().map(x -> {
                                if (x instanceof Double) {
                                    return (Double) x;
                                } else {
                                    throw new IllegalArgumentException("Wrong input params: [" + x + "]");
                                }
                            }).collect(Collectors.toList());


                            SortedSetDocValues docValues = DocValues.getSortedSet(context.reader(), feature.field());
                            String vectorStr = "";

                            boolean isDocExists = docValues.advanceExact(doc);
                            if (isDocExists) {
                                long ord;
                                while ((ord = docValues.nextOrd()) != SortedSetDocValues.NO_MORE_ORDS) {
                                    BytesRef bytesRef = docValues.lookupOrd(ord);
                                    vectorStr += bytesRef.utf8ToString();
                                }
                            }

                            double[] destVector = null;
                            if (vectorStr != "") {
                                String[] values = vectorStr.split(",");
                                destVector = new double[values.length];
                                for (int i = 0; i < values.length; i++) {
                                    destVector[i] = Double.valueOf(values[i]).doubleValue();
                                }
                            } else {
                                destVector = new double[1];
                                destVector[0] = 0.0;
                            }

                            if (srcVector.size() != destVector.length) {
                                score = 0;
                            } else {
                                switch (channel) {
                                    case "cosin": {
                                        double numerator = 0.0;
                                        double denominator = 0.0;
                                        for (int i = 0; i < srcVector.size(); i++) {
                                            denominator += (srcVector.get(i)) * (srcVector.get(i));
                                        }
                                        denominator = Math.sqrt(denominator);
                                        double square = 0.0;
                                        for (int i = 0; i < destVector.length; i++) {
                                            square += destVector[i] * destVector[i];
                                        }
                                        denominator *= Math.sqrt(square);
                                        for (int i = 0; i < srcVector.size(); i++) {
                                            numerator += srcVector.get(i) * destVector[i];
                                        }
                                        if (denominator == 0) {
                                            score = 0;
                                        } else {
                                            score = (float)(numerator/denominator);
                                        }
                                        break;
                                    }
                                    default:
                                        throw new IllegalArgumentException("Wrong channel: [" + feature.channel() + "]");
                                }
                            }

                            subs.add(Explanation.match(score, featureString, explain));
                            d.setFeatureScore(realordinal, score);
                            break;
                        }
                        case "non-discrete": {
                            subs.add(Explanation.match(explain.getValue(), featureString, explain));
                            d.setFeatureScore(realordinal, explain.getValue());
                            break;
                        }
                        default:
                            throw new IllegalArgumentException("Wrong attry_type: [" + attrType + "]");
                    }
                }
            }

            List<CrossFeature> crossFields = ranker.getCrossFeatures();
            List<String> crossFeatures = new ArrayList<>();
            Set<String> crossName = new HashSet<>();
            if (crossFields != null) {
                for (CrossFeature crossFeature : crossFields) {
                    List<String> fields = crossFeature.fields();
                    List<String> values = new ArrayList<>();

                    StringBuilder fname = new StringBuilder();
                    fields = fields.stream().filter(field -> null != field && !"".equals(field)).collect(Collectors.toList());
                    values = fields.stream().map(field -> fieldMap.get(field)).collect(Collectors.toList());
                    fname.append(String.join("_", fields));
                    //因为存在多个相同的name的交叉特征，这里需要做去重
                    if (!crossName.contains(fname.toString())) {
                        crossName.add(fname.toString());
                        fname.append(DELIMITER);

                        fname.append(String.join("_", values));
                        crossFeatures.add(fname.toString());
                    }
                }
            }

            SortedNumericDocValues docValues = DocValues.getSortedNumeric(context.reader(), "updatetm");
            long updatetm = 0;
            float tie = 0;
            if (docValues.nextDoc() != DocIdSetIterator.NO_MORE_DOCS) {
                updatetm = docValues.nextValue();
                tie = (float)((updatetm / 1000.0) / System.currentTimeMillis());
            }
            float modelScore = ranker.score(d, crossFeatures) + tie;
            return Explanation.match(modelScore, " LtrModel: " + ranker.name() + " using features:", subs);
        }

        @Override
        public RankerScorer scorer(LeafReaderContext context) throws IOException {
            List<Scorer> scorers = new ArrayList<>(weights.size());
            List<DocIdSetIterator> subIterators = new ArrayList<>(weights.size());
            MutableSupplier<LtrRanker.FeatureVector> vectorSupplier = new MutableSupplier<>();
            for (Weight weight : weights) {
                Scorer scorer;
                if (weight instanceof FeatureVectorWeight) {
                    scorer = ((FeatureVectorWeight) weight).scorer(context, vectorSupplier);
                } else {
                    scorer = weight.scorer(context);
                }
                if (scorer == null) {
                    scorer = new NoopScorer(this, DocIdSetIterator.empty());
                }
                scorers.add(scorer);
                subIterators.add(scorer.iterator());
            }


            NaiveDisjunctionDISI rankerIterator = new NaiveDisjunctionDISI(DocIdSetIterator.all(context.reader().maxDoc()), subIterators);
            return new RankerScorer(context, scorers, rankerIterator, vectorSupplier);
        }

        class RankerScorer extends Scorer {
            /**
             * NOTE: Switch to ChildScorer and {@link #getChildren()} if it appears
             * to be useful for logging
             */
            private final LeafReaderContext context;
            private final List<Scorer> scorers;
            private final NaiveDisjunctionDISI iterator;
            private final MutableSupplier<LtrRanker.FeatureVector> featureVector;

            RankerScorer(LeafReaderContext context, List<Scorer> scorers, NaiveDisjunctionDISI iterator, MutableSupplier<LtrRanker.FeatureVector> featureVector) {
                super(RankerWeight.this);
                this.context = context;
                this.scorers = scorers;
                this.iterator = iterator;
                this.featureVector = featureVector;
            }

            @Override
            public int docID() {
                return iterator.docID();
            }

            @Override
            public float score() throws IOException {
                LtrRanker.FeatureVector fv = featureVector.get();
                fv = ranker.newFeatureVector(fv);
                featureVector.set(fv);
                int ordinal = -1;
                // a DisiPriorityQueue could help to avoid
                // looping on all scorers
                //记录featurevector赋值标识, 这里已经对query和scores进行了压缩（针对discrete属性）
                //Map<Integer, Integer> evaluationIndicator = new HashMap<Integer, Integer> (scorers.size());

                //保存discrete属性的域对应的值,其中range类型属性的key为字段值，value为字段值对应的区间编号
                Map<String, String> fieldMap = new HashMap<>();
                for (Scorer scorer : scorers) {
                    ordinal++;
                    // FIXME: Probably inefficient, again we loop over all scorers..
                    if (scorer.docID() == docID()) {

                        int originOrdinal = getOriginalID(ordinal);
                        Feature feature = getFeature(originOrdinal);
                        float score = 0.0f;
                        List<String> queryParams = (List<String>) feature.queryParams();
                        String channel = feature.channel();
                        switch (feature.attrType()) {
                            case "categorical": {
                                //字段值，input型：传入参数获取， hybrid，query：从查询中获取
                                String fieldValue;
                                //是否找到了onehot的那位，因为hybrid型需要再匹配一次(不一定每个样本都有onehot bit），input和query类型一定有onehot bit
                                boolean find = true;

                                switch (channel) {
                                    case "input": {
                                        String key = queryParams.get(0);
                                        Object value = params.get(key);
                                        //先获取传入的值
                                        fieldValue = value.toString();
                                        if (value instanceof Integer) {
                                            Integer tempValue = (Integer)value;
                                            if (tempValue > feature.max()) {
                                                fieldValue = Integer.toString(0);
                                            }
                                        }
                                        break;
                                    }
                                    //既查询又匹配型特征
                                    case "hybrid":
                                    case "query":
                                    case "binary": {
                                        score = scorer.score();
                                        //categorical 属性的值得从0开始（不支持string类型,float类型）
                                        //属性增加field字段，categorical属性命名：field名=field值，都必须是string类型
                                        switch (feature.fieldType()) {
                                            case "int": {
                                                if ((int) score > feature.max()) {
                                                    score = 0f;
                                                }
                                                fieldValue = Integer.toString((int) score);
                                                break;
                                            }
                                            default:
                                                throw new IllegalArgumentException("Wrong field_type: [" + feature.fieldType() + "]");
                                        }

                                        //混合型还需要匹配params step 1: 解析传入的参数，这里是个list integer
                                        if (channel.equals("hybrid") || channel.equals("binary")) {
                                            String key = queryParams.get(0);
                                            Object values = params.get(key);
                                            //加上抑制处理，否则在编译时报错
                                            @SuppressWarnings("unchecked")
                                            List<Object> a = (ArrayList<Object>) values;
                                            List<Integer> objects = a.stream().map(x -> {
                                                if (x instanceof Integer) {
                                                    return (Integer) x;
                                                } else {
                                                    throw new IllegalArgumentException("Wrong input params: [" + x + "]");
                                                }
                                            }).collect(Collectors.toList());

                                            //step 2: 根据查询的值来匹配传入的参数
                                            if (objects.contains((int) score)) {
                                                find = true;
                                                //字段值为1
                                                if (channel.equals("binary")){
                                                    fieldValue = Integer.toString(1);
                                                }
                                            } else {
                                                find = false;
                                                //字段值为0
                                                if (channel.equals("binary")){
                                                    fieldValue = Integer.toString(0);
                                                }
                                            }
                                        }
                                        break;
                                    }
                                    default:
                                        throw new IllegalArgumentException("Wrong channel type: [" + channel + "]");
                                }

                                //保存离散型特征的具体字段值，用于交叉特征时找到具体的维度
                                fieldMap.put(feature.field(), fieldValue);
                                String featureString = feature.field() + DELIMITER + fieldValue;
                                int pos = featureOrdinal(featureString);
                                //这里由于对categorical属性进行了压缩，直接设置对应位置
                                if (find) {
                                    fv.setFeatureScore(pos, 1);
                                }
                                break;
                            }
                            case "range": {
                                score = scorer.score();
                                fv.setFeatureScore(originOrdinal, score);
                                //将对应k-v保存到fieldMap以便交叉变量使用
                                if ((int)score == 1) {
                                    int index = feature.index();
                                    fieldMap.put(feature.field(), Integer.toString(index));
                                }
                                break;
                            }
                            case "embedding": {
                                String key = queryParams.get(0);
                                Object objects = params.get(key);
                                @SuppressWarnings("unchecked")
                                List<Object> a = (ArrayList<Object>) objects;
                                List<Double> srcVector = a.stream().map(x -> {
                                    if (x instanceof Double) {
                                        return (Double) x;
                                    } else {
                                        throw new IllegalArgumentException("Wrong input params: [" + x + "]");
                                    }
                                }).collect(Collectors.toList());

                                SortedSetDocValues docValues = DocValues.getSortedSet(context.reader(), feature.field());
                                String vectorStr = "";
                                boolean isDocExists = docValues.advanceExact(docID());
                                if (isDocExists) {
                                    long ord;
                                    while ((ord = docValues.nextOrd()) != SortedSetDocValues.NO_MORE_ORDS) {
                                        BytesRef bytesRef = docValues.lookupOrd(ord);
                                        vectorStr += bytesRef.utf8ToString();
                                    }
                                }

                                //logger.info(feature.field() + ":" + vectorStr);
                                double[] destVector = null;
                                if (vectorStr != "") {
                                    String[] values = vectorStr.split(",");
                                    destVector = new double[values.length];
                                    for (int i = 0; i < values.length; i++) {
                                        destVector[i] = Double.valueOf(values[i]).doubleValue();
                                    }
                                } else {
                                    destVector = new double[1];
                                    destVector[0] = 0.0;
                                }


                                if (srcVector.size() != destVector.length) {
                                    score = 0;
                                } else {
                                    switch (channel) {
                                        case "cosin": {
                                            double numerator = 0.0;
                                            double denominator = 0.0;
                                            for (int i = 0; i < srcVector.size(); i++) {
                                                denominator += (srcVector.get(i)) * (srcVector.get(i));
                                            }
                                            denominator = Math.sqrt(denominator);
                                            double square = 0.0;
                                            for (int i = 0; i < destVector.length; i++) {
                                                square += destVector[i] * destVector[i];
                                            }
                                            denominator *= Math.sqrt(square);
                                            for (int i = 0; i < srcVector.size(); i++) {
                                                numerator += srcVector.get(i) * destVector[i];
                                            }

                                            if (denominator == 0) {
                                                score = 0;
                                            } else {
                                                score = (float)(numerator/denominator);
                                            }
                                            break;
                                        }
                                        default:
                                            throw new IllegalArgumentException("Wrong channel: [" + feature.channel() + "]");

                                    }
                                }
                                fv.setFeatureScore(originOrdinal, score);
                                break;
                            }
                            case "non-discrete" : {
                                score = scorer.score();
                                fv.setFeatureScore(originOrdinal, score);
                                break;
                            }
                            default:
                                throw new IllegalArgumentException("Wrong attr_type: [" + feature.attrType() + "]");

                            // XXX: bold assumption that all models are dense
                            // do we need a some indirection to infer the featureId?
                            //if (!evaluationIndicator.containsKey(ordinal)){

                            //evaluationIndicator.put(ordinal, 1);
                            //}
                        }
                    }
                }

                List<CrossFeature> crossFields = ranker.getCrossFeatures();
                List<String> crossFeatures = new ArrayList<>();
                Set<String> crossName = new HashSet<>();
                if (crossFields != null) {
                  for (CrossFeature crossFeature : crossFields) {
                    List<String> fields = crossFeature.fields();
                    List<String> values = new ArrayList<>();

                    StringBuilder fname = new StringBuilder();

                    fields = fields.stream().filter(field -> null != field && !"".equals(field)).collect(Collectors.toList());
                    values = fields.stream().map(field -> fieldMap.get(field)).collect(Collectors.toList());
                    fname.append(String.join("_", fields));
                    //因为存在多个相同的name的交叉特征，这里需要做去重
                    if (!crossName.contains(fname.toString())) {
                        crossName.add(fname.toString());
                        fname.append(DELIMITER);

                        fname.append(String.join("_", values));
                        crossFeatures.add(fname.toString());
                    }
                }
            }
                SortedNumericDocValues docValues = DocValues.getSortedNumeric(context.reader(), "updatetm");
                long updatetm = 0;
                float tie = 0;
                if (docValues.nextDoc() != DocIdSetIterator.NO_MORE_DOCS) {
                    updatetm = docValues.nextValue();
                    tie = (float)((updatetm / 1000.0) / System.currentTimeMillis());
                }


                return ranker.score(fv, crossFeatures) + tie;
            }

//            @Override
//            public int freq() throws IOException {
//                return scorers.size();
//            }

            @Override
            public DocIdSetIterator iterator() {
                return iterator;
            }
        }
    }

    /**
     * Driven by a main iterator and tries to maintain a list of sub iterators
     * Mostly needed to avoid calling {@link Scorer#iterator()} to directly advance
     * from {@link RankerWeight.RankerScorer#score()} as some Scorer implementations
     * will instantiate new objects every time iterator() is called.
     * NOTE: consider using {@link org.apache.lucene.search.DisiPriorityQueue}?
     */
    static class NaiveDisjunctionDISI extends DocIdSetIterator {
        private final DocIdSetIterator main;
        private final List<DocIdSetIterator> subIterators;

        NaiveDisjunctionDISI(DocIdSetIterator main, List<DocIdSetIterator> subIterators) {
            this.main = main;
            this.subIterators = subIterators;
        }

        @Override
        public int docID() {
            return main.docID();
        }

        @Override
        public int nextDoc() throws IOException {
            int doc = main.nextDoc();
            advanceSubIterators(doc);
            return doc;
        }

        @Override
        public int advance(int target) throws IOException {
            int docId = main.advance(target);
            advanceSubIterators(docId);
            return docId;
        }

        private void advanceSubIterators(int target) throws IOException {
            if (target == NO_MORE_DOCS) {
                return;
            }
            for (DocIdSetIterator iterator : subIterators) {
                // FIXME: Probably inefficient
                if (iterator.docID() < target) {
                    iterator.advance(target);
                }
            }
        }

        @Override
        public long cost() {
            return main.cost();
        }
    }
}

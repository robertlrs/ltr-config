package com.o19s.es.ltr.feature.store;

import com.o19s.es.ltr.LtrQueryContext;
import com.o19s.es.ltr.feature.Feature;
import com.o19s.es.ltr.feature.FeatureSet;
import com.o19s.es.ltr.feature.store.script.FunctionScore;
import com.o19s.es.ltr.feature.store.script.TemplateContent;
import com.o19s.es.template.mustache.MustacheUtils;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.util.Accountable;
import org.apache.lucene.util.RamUsageEstimator;
import org.elasticsearch.common.ParseField;
import org.elasticsearch.common.ParsingException;
import org.elasticsearch.common.bytes.BytesReference;
import org.elasticsearch.common.io.stream.StreamInput;
import org.elasticsearch.common.io.stream.StreamOutput;
import org.elasticsearch.common.lucene.search.function.FunctionScoreQuery;
import org.elasticsearch.common.lucene.search.function.ScoreFunction;
import org.elasticsearch.common.lucene.search.function.ScriptScoreFunction;
import org.elasticsearch.common.xcontent.*;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryShardException;
import org.elasticsearch.index.query.Rewriteable;
import org.elasticsearch.script.*;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_ARRAY_HEADER;
import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_OBJECT_HEADER;
import static org.apache.lucene.util.RamUsageEstimator.NUM_BYTES_OBJECT_REF;
import static org.elasticsearch.index.query.AbstractQueryBuilder.parseInnerQueryBuilder;

/**
 * @author: zhou yafeng
 * @create: 2018/07/06
 */
public class StoredFeature implements Feature, Accountable, StorableElement {
    private static final long BASE_RAM_USED = RamUsageEstimator.shallowSizeOfInstance(StoredFeature.class);
    private static final String DEFAULT_TEMPLATE_LANGUAGE = MustacheUtils.TEMPLATE_LANGUAGE;
    public static final String TYPE = "feature";
    private final String name;
    private final List<String> queryParams;
    private final String templateLanguage;
    private final String template;
    private final String attrType;
    private final String channel;
    private final int index;
    private final int max;
    private final String field;
    private final String fieldType;
    private final boolean templateAsString;

    private static final ObjectParser<ParsingState, Void> PARSER;

    private static final ParseField NAME = new ParseField("name");
    private static final ParseField PARAMS = new ParseField("params");
    private static final ParseField TEMPLATE_LANGUAGE = new ParseField("template_language");
    public static final ParseField TEMPLATE = new ParseField("template");
    private static final ParseField ATTRTYPE = new ParseField("type");
    private static final ParseField CHANNEL = new ParseField("channel");
    private static final ParseField INDEX = new ParseField("index");
    private static final ParseField MAX = new ParseField("max");
    private static final ParseField FIELD = new ParseField("field");
    private static final ParseField FIELDTYPE = new ParseField("field_type");

    static {
        PARSER = new ObjectParser<>(TYPE, com.o19s.es.ltr.feature.store.StoredFeature.ParsingState::new);
        PARSER.declareString(ParsingState::setName, NAME);
        PARSER.declareStringArray(ParsingState::setQueryParams, PARAMS);
        PARSER.declareString(ParsingState::setTemplateLanguage, TEMPLATE_LANGUAGE);
        PARSER.declareString(ParsingState::setTemplateType, ATTRTYPE);
        PARSER.declareString(ParsingState::setChannel, CHANNEL);
        PARSER.declareInt(ParsingState::setFeatureIndex, INDEX);
        PARSER.declareInt(ParsingState::setMax, MAX);
        PARSER.declareString(ParsingState::setField, FIELD);
        PARSER.declareString(ParsingState::setFieldType, FIELDTYPE);

        PARSER.declareField(ParsingState::setTemplate, (parser, value) -> {
            if (parser.currentToken() == XContentParser.Token.START_OBJECT) {
                // Force json
                try (XContentBuilder builder = XContentFactory.contentBuilder(XContentType.JSON)) {
                    return builder.copyCurrentStructure(parser);
                } catch (IOException e) {
                    throw new ParsingException(parser.getTokenLocation(), "Could not parse inline template", e);
                }
            } else {
                return parser.text();
            }
        }, TEMPLATE, ObjectParser.ValueType.OBJECT_OR_STRING);
    }

    public StoredFeature(String name, String type, String channel, int index, int max, List<String> params, String field, String fieldType, String templateLanguage, String template, boolean storedAsString) {
        this.name = Objects.requireNonNull(name);
        this.attrType = Objects.requireNonNull(type);
        this.channel = Objects.requireNonNull(channel);
        this.index = Objects.requireNonNull(index);
        this.max = Objects.requireNonNull(max);
        this.queryParams = Objects.requireNonNull(params);
        this.field = Objects.requireNonNull(field);
        this.fieldType = Objects.requireNonNull(fieldType);
        this.templateLanguage = Objects.requireNonNull(templateLanguage);
        this.template = Objects.requireNonNull(template);
        this.templateAsString = storedAsString;
    }

    public StoredFeature(StreamInput input) throws IOException {
        name = input.readString();
        attrType = input.readString();
        channel = input.readString();
        index = input.readInt();
        max = input.readInt();
        queryParams = input.readList(StreamInput::readString);
        field = input.readString();
        fieldType = input.readString();
        templateLanguage = input.readString();
        template = input.readString();
        templateAsString = input.readBoolean();
    }

    public StoredFeature(String name, String type, String channel, int index, int max, List<String> params, String field, String fieldType, String templateLanguage, String template) {
        this(name, type, channel, index, max, params, field, fieldType, templateLanguage, template, true);
    }

    public StoredFeature(String name, String type, String channel, int index, int max, List<String> params, String field, String fieldType, String templateLanguage, XContentBuilder template) {
        this(name, type, channel, index, max, params, field, fieldType, templateLanguage, Objects.requireNonNull(template).bytes().utf8ToString(), false);
    }

    @Override
    public void writeTo(StreamOutput out) throws IOException {
        out.writeString(name);
        out.writeString(attrType);
        out.writeString(channel);
        out.writeInt(index);
        out.writeInt(max);
        out.writeStringList(queryParams);
        out.writeString(field);
        out.writeString(fieldType);
        out.writeString(templateLanguage);
        out.writeString(template);
        out.writeBoolean(templateAsString);
    }

    @Override
    public XContentBuilder toXContent(XContentBuilder builder, Params params) throws IOException {
        builder.startObject();
        builder.field(NAME.getPreferredName(), name);
        builder.field(ATTRTYPE.getPreferredName(), attrType);
        builder.field(CHANNEL.getPreferredName(), channel);
        builder.field(INDEX.getPreferredName(), index);
        builder.field(MAX.getPreferredName(), max);
        builder.field(PARAMS.getPreferredName(), queryParams);
        builder.field(FIELD.getPreferredName(), field);
        builder.field(FIELDTYPE.getPreferredName(), fieldType);
        builder.field(TEMPLATE_LANGUAGE.getPreferredName(), templateLanguage);
        if (templateAsString) {
            builder.field(TEMPLATE.getPreferredName(), template);
        } else {
            builder.field(TEMPLATE.getPreferredName());
            // it's ok to use NamedXContentRegistry.EMPTY because we don't really parse we copy the structure...
            XContentParser parser = XContentFactory.xContent(template).createParser(NamedXContentRegistry.EMPTY, template);
            builder.copyCurrentStructure(parser);
        }
        builder.endObject();
        return builder;
    }

    public static StoredFeature parse(XContentParser parser) {
        return parse(parser, null);
    }


    public static StoredFeature parse(XContentParser parser, String name) {
        try {
            ParsingState state = PARSER.apply(parser, null);
            state.resolveName(parser, name);
            if (state.queryParams == null) {
                state.queryParams = Collections.emptyList();
            }
            if (state.template == null) {
                throw new ParsingException(parser.getTokenLocation(), "Field [template] is mandatory");
            }
            if (state.template instanceof String) {
                return new StoredFeature(state.getName(), state.type, state.channel, state.index, state.max, Collections.unmodifiableList(state.queryParams),
                        state.field, state.fieldType, state.templateLanguage, (String) state.template);
            } else {
                assert state.template instanceof XContentBuilder;
                return new StoredFeature(state.getName(), state.type, state.channel, state.index, state.max, Collections.unmodifiableList(state.queryParams),
                        state.field, state.fieldType, state.templateLanguage, (XContentBuilder) state.template);
            }
        } catch (IllegalArgumentException iae) {
            throw new ParsingException(parser.getTokenLocation(), iae.getMessage(), iae);
        }
    }

    @Override
    public Feature optimize() {
        switch (templateLanguage) {
            case MustacheUtils.TEMPLATE_LANGUAGE:
                return PrecompiledTemplateFeature.compile(this);
            case PrecompiledExpressionFeature.TEMPLATE_LANGUAGE:
                return PrecompiledExpressionFeature.compile(this);
            default:
                return this;
        }
    }

    @Override
    public String name() {
        return name;
    }

    public String type() {
        return TYPE;
    }


    @Override
    public Query doToQuery(LtrQueryContext context, FeatureSet set, Map<String, Object> params) {
        List<String> missingParams = queryParams.stream()
                .filter((x) -> params == null || !params.containsKey(x))
                .collect(Collectors.toList());

        if (!missingParams.isEmpty()) {
            String names = missingParams.stream().collect(Collectors.joining(","));
            throw new IllegalArgumentException("Missing required param(s): [" + names + "]");
        }

        // mustache templates must be optimized
        assert !DEFAULT_TEMPLATE_LANGUAGE.equals(templateLanguage);
        // XXX: we hope that in most case users will use mustache that is embedded in the plugin
        // compiling the template from the script engine may hit a circuit breaker
        // TODO: verify that this actually works, it does not feel right

        try {
            XContentParser parser = XContentFactory.xContent(template).createParser(NamedXContentRegistry.EMPTY, template);

            FunctionScore functionScore =  TemplateContent.parse(parser);

            Script script = new Script(ScriptType.INLINE, "painless", functionScore.getScriptScore().getScriptFunction().getSource(), new HashMap<>(), params);

            SearchScript.Factory factory = context.getQueryShardContext().getScriptService().compile(script, SearchScript.CONTEXT);

            SearchScript.LeafFactory searchScript = factory.newFactory(script.getParams(), context.getQueryShardContext().lookup());

            ScoreFunction scoreFunction = new ScriptScoreFunction(script, searchScript);

            Query query = new FunctionScoreQuery(new MatchAllDocsQuery(), scoreFunction);

            return query;
        } catch (IOException e) {
            throw new QueryShardException(context.getQueryShardContext(), "Cannot create query while parsing feature [" + name + "]", e);
        }




//        ExecutableScript script = context.getQueryShardContext().getScriptService().compile(new Script(ScriptType.INLINE,
//            templateLanguage, template, params), new ScriptContext<>("search", ExecutableScript.class));
//        Object source = script.run();
//
//        try {
//            XContentParser parser = createParser(source, context.getQueryShardContext().getXContentRegistry());
//            QueryBuilder queryBuilder = parseInnerQueryBuilder(parser);
//            // XXX: QueryShardContext extends QueryRewriteContext (for now)
//            return Rewriteable.rewrite(queryBuilder, context.getQueryShardContext()).toQuery(context.getQueryShardContext());
//        } catch (IOException | ParsingException | IllegalArgumentException e) {
//            // wrap common exceptions as well so we can attach the feature's name to the stack
//            throw new QueryShardException(context.getQueryShardContext(), "Cannot create query while parsing feature [" + name + "]", e);
//        }
    }

    private XContentParser createParser(Object source, NamedXContentRegistry registry) throws IOException {
        if (source instanceof String) {
            return XContentFactory.xContent((String) source).createParser(registry, (String) source);
        } else if (source instanceof BytesReference) {
            return XContentFactory.xContent((BytesReference) source).createParser(registry, (BytesReference) source);
        } else if (source instanceof byte[]) {
            return XContentFactory.xContent((byte[]) source).createParser(registry, (byte[]) source);
        } else {
            throw new IllegalArgumentException("FunctionScore engine returned an unsupported object type [" +
                    source.getClass().getCanonicalName() + "]");
        }
    }

    @Override
    public Collection<String> queryParams() {
        return queryParams;
    }

    @Override
    public String field() {
        return field;
    }

    @Override
    public String fieldType() {
        return fieldType;
    }

    String templateLanguage() {
        return templateLanguage;
    }

    String template() {
        return template;
    }

    @Override
    public String attrType() {
        return attrType;
    }

    @Override
    public String channel() {
        return channel;
    }

    @Override
    public int index() {
        return index;
    }

    @Override
    public int max() {
        return max;
    }

    boolean templateAsString() {
        return templateAsString;
    }

    @Override
    public long ramBytesUsed() {
        // rough estimation...
        return BASE_RAM_USED +
                (Character.BYTES * name.length()) + (Character.BYTES * attrType.length()) +
                (Character.BYTES * attrType.length()) + 4 + 4 +
                NUM_BYTES_ARRAY_HEADER +
                queryParams.stream().mapToLong(x -> (Character.BYTES * x.length()) +
                        NUM_BYTES_OBJECT_REF + NUM_BYTES_OBJECT_HEADER + NUM_BYTES_ARRAY_HEADER).sum() +
                Character.BYTES * field.length() + Character.BYTES * fieldType.length() +
                (Character.BYTES * templateLanguage.length()) + NUM_BYTES_ARRAY_HEADER +
                (Character.BYTES * template.length()) + NUM_BYTES_ARRAY_HEADER;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof StoredFeature)) {
            return false;
        }

        StoredFeature feature = (StoredFeature) o;
        if (templateAsString != feature.templateAsString) {
            return false;
        }
        if (!name.equals(feature.name)) {
            return false;
        }

        if (!attrType.equals(feature.attrType)) {
            return false;
        }

        if (!channel.equals(feature.channel)) {
            return false;
        }

        if (index != feature.index) {
            return false;
        }

        if (max != feature.max) {
            return false;
        }
        if (!queryParams.equals(feature.queryParams)) {
            return false;
        }

        if (field.equals(feature.field)) {
            return false;
        }

        if (fieldType.equals(feature.fieldType)) {
            return false;
        }

        if (!templateLanguage.equals(feature.templateLanguage)) {
            return false;
        }
        return template.equals(feature.template);
    }

    @Override
    public int hashCode() {
        int result = name.hashCode();
        result = 31 * result + attrType.hashCode();
        result = 31 * result + channel.hashCode();
        result = 31 * result + index;
        result = 31 * result + max;
        result = 31 * result + queryParams.hashCode();
        result = 31 * result + field.hashCode();
        result = 31 * result + fieldType.hashCode();
        result = 31 * result + templateLanguage.hashCode();
        result = 31 * result + template.hashCode();
        result = 31 * result + (templateAsString ? 1 : 0);
        return result;
    }

    private static class ParsingState extends StorableElementParserState {
        private List<String> queryParams;
        private String templateLanguage = DEFAULT_TEMPLATE_LANGUAGE;
        private Object template;
        private String type;
        private String channel;
        private int index;
        private int max;
        private String field;
        private String fieldType;

        void setQueryParams(List<String> queryParams) {
            this.queryParams = queryParams;
        }

        void setTemplateLanguage(String templateLanguage) {
            this.templateLanguage = templateLanguage;
        }

        void setTemplateType(String type) {
            this.type = type;
        }

        void setChannel(String channel) {
            this.channel = channel;
        }

        void setFeatureIndex(int index) {
            this.index = index;
        }

        void setMax(int max) {
            this.max = max;
        }

        void setField(String field) {
            this.field = field;
        }

        void setFieldType(String fieldType) {
            this.fieldType = fieldType;
        }

        void setTemplate(Object template) {
            assert template instanceof String || template instanceof XContentBuilder;
            this.template = template;
        }
    }
}

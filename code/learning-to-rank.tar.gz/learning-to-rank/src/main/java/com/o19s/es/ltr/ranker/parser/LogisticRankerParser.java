package com.o19s.es.ltr.ranker.parser;

import com.o19s.es.ltr.feature.CrossFeature;
import com.o19s.es.ltr.feature.FeatureSet;
import com.o19s.es.ltr.feature.FeatureValidation;
import com.o19s.es.ltr.ranker.linear.LogisticRanker;
import org.elasticsearch.common.ParseField;
import org.elasticsearch.common.ParsingException;
import org.elasticsearch.common.xcontent.NamedXContentRegistry;
import org.elasticsearch.common.xcontent.ObjectParser;
import org.elasticsearch.common.xcontent.XContentParser;
import org.elasticsearch.common.xcontent.json.JsonXContent;

import java.io.IOException;
import java.util.*;

/**
 * @author: zhou yafeng
 * @create: 2018/06/27
 */
public class LogisticRankerParser implements LtrRankerParser{
    public static String TYPE = "model/logistic";
    public static String DELIMITER = "=";

    @Override
    public LogisticRanker parse(FeatureSet set, String model) {
        float[] weights = new float[set.size()];
        Map<String, Float> cross_weights = new HashMap<>();
        List<CrossFeature> cross_fields = new ArrayList<>();
        Set<String> crossFnames = new HashSet<>();
        try (XContentParser parser = JsonXContent.jsonXContent.createParser(NamedXContentRegistry.EMPTY, model)) {
            XContentParser.Token token = parser.nextToken();
            XContentParser.Token currentToken = parser.currentToken();
            if (token != XContentParser.Token.START_ARRAY) {
                throw new ParsingException(parser.getTokenLocation(), "Expected [START_ARRAY] but got [" + parser.currentToken() + "]");
            }
            //XContentParser.Token nextToken = parser.nextToken();
            while (parser.nextToken() != XContentParser.Token.END_ARRAY) {
                SplitParserState split = SplitParserState.parse(parser, set);
                StringBuilder fname = new StringBuilder();
                List<String> fields = split.featureString;

                //交叉特征的name 域
                if (fields.size() > 1) {
                    for (int i = 0; i < fields.size(); i++){
                        String field = fields.get(i);
                        if (!set.hasField(field)) {
                            throw new ParsingException(parser.getTokenLocation(), "Field [" + field + "] is unknown.");
                        }

                        if (fname.toString().equals("")){
                            fname.append(field);
                        }else {
                            fname.append("_");
                            fname.append(field);
                        }
                    }
                    if (!crossFnames.contains(fname.toString())) {
                        crossFnames.add(fname.toString());
                        cross_fields.add(new CrossFeature(fields));
                    }
                } else {
                    String feature = fields.get(0);
                    fname.append(feature);
                }

                List<String> terms = split.featureId;
                if (terms.size() > 0){
                    fname.append(DELIMITER);
                    for (int i = 0; i < terms.size(); i++){
                        String term = terms.get(i);

                        if (i == 0) {
                            fname.append(term);
                        }else{
                            fname.append("_");
                            fname.append(term);
                        }
                    }
                    //离散特征，非交叉
                    if (terms.size() == 1) {
                        String feature = fname.toString();
                        if (!set.hasFeature(feature)) {
                            throw new ParsingException(parser.getTokenLocation(), "Feature [" + feature + "] is unknown.");
                        }
                    }
                } //单一特征
                else {
                    String feature = fname.toString();
                    if (!set.hasFeature(feature)) {
                        throw new ParsingException(parser.getTokenLocation(), "Feature [" + feature + "] is unknown.");
                    }

                }
                String feature = fname.toString();
                //交叉特征
                if (fields.size() > 1) {
                    cross_weights.put(feature, split.weight);
                }//非交叉特征
                else{
                   weights[set.featureOrdinal(feature)]  = split.weight;
                }
            }
        } catch (IOException e) {
            throw new IllegalArgumentException("Cannot parse model", e);
        }

        return new LogisticRanker(weights, cross_weights, cross_fields);
    }

    private static class SplitParserState {
        private static final ObjectParser<SplitParserState, FeatureSet> PARSER;
        static {
            PARSER = new ObjectParser<SplitParserState, FeatureSet>("feature", SplitParserState::new);
            PARSER.declareStringArray(SplitParserState::setName, new ParseField("name"));
            PARSER.declareStringArray(SplitParserState::setTerm, new ParseField("term"));
            PARSER.declareFloat(SplitParserState::setWeight, new ParseField("weight"));
        }

        private List<String> featureString;
        private List<String> featureId;
        private Float weight;

        public static SplitParserState parse(XContentParser parser, FeatureSet set) {
            SplitParserState split = PARSER.apply(parser, set);
            return split;
        }
        void setName(List<String> name) {
            this.featureString = name;
        }

        void setTerm(List<String> term) {
            this.featureId = term;
        }


        void setWeight(Float weight) {
            this.weight = weight;
        }

    }
}

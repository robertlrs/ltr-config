package com.o19s.es.ltr.feature.store.script;


import org.elasticsearch.common.ParseField;
import org.elasticsearch.common.xcontent.ObjectParser;
import org.elasticsearch.common.xcontent.XContentParser;

public class FunctionScore {

    public static final String TYPE = "function_score";

    private static final ObjectParser<ParsingState, Void> PARSER;

    private ScriptScore scriptScore;

    static final ParseField SCRIPT_SCORE = new ParseField("script_score");

    static {
        PARSER = new ObjectParser<>(TYPE, ParsingState::new);
        PARSER.declareObject(ParsingState::setScriptScore,
            (parser, ctx) -> ScriptScore.parse(parser),
            SCRIPT_SCORE);
    }

    public static FunctionScore parse(XContentParser parser) {
        ParsingState state = PARSER.apply(parser, null);

        FunctionScore functionScore = new FunctionScore();
        functionScore.scriptScore = state.scriptScore;

        return functionScore;
    }

    public ScriptScore getScriptScore() {
        return scriptScore;
    }

    public void setScriptScore(ScriptScore scriptScore) {
        this.scriptScore = scriptScore;
    }


    private static class ParsingState {
        ScriptScore scriptScore;

        void setScriptScore(ScriptScore scriptScore) {
            this.scriptScore = scriptScore;
        }
    }
}
